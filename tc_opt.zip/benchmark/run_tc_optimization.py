#!/usr/bin/env python3
"""
Script to compile all triangle counting optimization configurations.
Logs all build output to a file for later analysis.
"""

import subprocess
import sys
from pathlib import Path
from datetime import datetime

# Configuration arrays - these match the generated cpp files
OMP_SCHEDULES = [
    "dynamic_4",
    "dynamic_8",
    "dynamic_16",
    "dynamic_32",
    "dynamic_64",
    "guided",
]

PARTITION_SCALES = [200, 250, 300, 350]

# Build directory
BENCHMARK_DIR = Path("/systems/FlexoGraph/build/debug")
LOGS_DIR = BENCHMARK_DIR / "optimization_logs"

# Build command
BUILD_CMD = ["make", "-j"]


def main():
    """Main execution function."""
    print("="*80)
    print("Triangle Counting Optimization Build Script")
    print("="*80)
    print(f"Build Directory: {BENCHMARK_DIR}")
    print(f"Logs Directory: {LOGS_DIR}")
    print(f"Total configurations: {len(OMP_SCHEDULES) * len(PARTITION_SCALES)}")
    print("="*80)

    # Verify build directory exists
    if not BENCHMARK_DIR.exists():
        print(f"ERROR: Build directory not found: {BENCHMARK_DIR}")
        return 1

    # Create logs directory
    LOGS_DIR.mkdir(parents=True, exist_ok=True)

    # Create log file with timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = LOGS_DIR / f"build_all_{timestamp}.log"

    print(f"\nStarting build...")
    print(f"Output will be logged to: {log_file}")
    print(f"You can tail the log with: tail -f {log_file}\n")

    try:
        # Open log file for writing with line buffering
        with open(log_file, 'w', buffering=1) as f:
            # Write header
            header = f"""{'='*80}
Triangle Counting Optimization Build Log
Started: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
Build Directory: {BENCHMARK_DIR}
Command: {' '.join(BUILD_CMD)}
{'='*80}

"""
            f.write(header)
            f.flush()
            print(header)

            # Run make with stdout and stderr merged
            process = subprocess.Popen(
                BUILD_CMD,
                cwd=BENCHMARK_DIR,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,  # Merge stderr into stdout
                text=True,
                bufsize=1  # Line buffered
            )

            # Stream output line by line to both log file and console
            for line in process.stdout:
                f.write(line)
                f.flush()  # Ensure immediate write for tailing
                print(line, end='')  # Also print to console

            # Wait for process to complete
            return_code = process.wait()

            # Write footer
            footer = f"""
{'='*80}
Build completed: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
Return Code: {return_code}
{'='*80}
"""
            f.write(footer)
            f.flush()
            print(footer)

        if return_code == 0:
            print(f"\n✓ Build successful!")
            print(f"All optimization configurations have been compiled.")
            print(f"\nExecutable names:")
            for schedule in OMP_SCHEDULES:
                for scale in PARTITION_SCALES:
                    exe_name = f"tc_opt_{schedule}_scale{scale}"
                    print(f"  - {exe_name}")
        else:
            print(f"\n✗ Build failed with return code {return_code}")
            print(f"Check the log file for details: {log_file}")

        print(f"\nLog file saved to: {log_file}")
        return return_code

    except KeyboardInterrupt:
        print("\n\nBuild interrupted by user!")
        return 130
    except Exception as e:
        print(f"\nError during build: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
